# Card Expansion Effect

A morphing card expansion effect enhanced by a low poly background animation, using SVG clipPath and Trianglify.

[Article on Codrops](http://tympanus.net/codrops/?p=24222)

[Demo](http://tympanus.net/Development/CardExpansion/)

## License

Created by Claudio Calautti for Codrops. Released under the [GNU GPL license v3](https://www.gnu.org/licenses/gpl-3.0.html).

Follow us: [Twitter](http://www.twitter.com/codrops), [Facebook](http://www.facebook.com/pages/Codrops/159107397912), [Google+](https://plus.google.com/101095823814290637419), [GitHub](https://github.com/codrops), [Pinterest](http://www.pinterest.com/codrops/)

[© Codrops 2015](http://www.codrops.com)


