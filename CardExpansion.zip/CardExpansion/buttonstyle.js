jQuery(document).ready(function(){
    $('.button').click(function(){
      $('.one').addClass('oneani');
      $('.two').addClass('twoani');
    });
  })